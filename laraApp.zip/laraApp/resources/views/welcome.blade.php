<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

        <link href="/css/style.css" rel="stylesheet" >

    </head>
    <body>
    <!------ Nav Bar 
    <nav class="navbar navbar-dark bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#">Navbar</a>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/about">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">services offered by tour manager</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/contact">Contact us</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>------>

<div class="container pt-3">
	<div class="row">
		<div class="col-6">
<i class="fas fa-code fa-2x text-warning" ></i>
<h5 class="text-white d-inline" >Travels Nest</h5>
		</div>

		<div class="col-6 pt-2">
		<div class="row">
			<div class="col-2 ">
				<a href="#about" class="text-white navigation-link">About</a>
			</div>

			<div class="col-2">
				<a href="#Places" class="text-white navigation-link">Places</a>
			</div>
		</div>	
		</div>
	</div>
</div>
<div class="container main-container">
	<div class="row main_row">
		<div class="col-6">
			<h2 class="text-white"></h2>
			<div class="name">
			<h2 class="text-white ">Welcome</h2>
			<h2 class="text-secondary">Eleutheromanians </h2>
</div>	
		</div> 
		<div class="col-6">
			<img class="img" src="images/vv.png">
		</div>
	</div>
</div>

<div id="about" class="container">
	<div class="row">
		<div class="col-6">
			<img  src="images/oo.png" class="img-fluid">
		</div>
		<div class="col-6 pl-5 pt-5 pb-5 text-white">
			<h3 class="text-warning">About us</h3>
			<h1 class="text-white">A bit to know Us</h1>
		  <p>A travel agency is a private retailer or public service that provides the <b class="text-warning">tours</b> travels related services to the general and public on behalf of accommodation or <b class="text-warning">travel suppilers</b></p>
      <p>A agency is a main function that act as an agent,selling <b class="text-warning">travel products</b> and services on behalf of supplier they dont keep inventonry in-hand unless they have <b class="text-warning">pre-booked hotel rooms</b> or cabins on a cruise ship for a group travel event such as a wedding,honeymoon or other group event</p>	
    </div>
	</div>
</div>
<div id="Places" class="container mt-3 pt-5">
	<h1 class="text-warning mb-3 pb-2">< Places></h1>
	<div class="row">
		<div class="COL-4 ml-4 mr-5 mb-5">
			<div class="card" style="width: 18rem;">
  <img src="images/3.jpg.jpg" class=" card card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title pt-3">Goa</h5>
    <p class="card-text">Goa tourism is a popular for beaches,nightlife,sighseeing and adventurous activities.</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
<div class="COL-4 mr-4 ml-5">
			<div class="card" style="width: 18rem;">
  <img src="images/5.jpg.jpeg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title pt-3">Manali</h5>
    <p class="card-text">Manali tourism is also famous for adventure sports like skiing,hiking,mountaineering,paragliding,rafting</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
<div class="COL-4 ml-5">
			<div class="card" style="width: 18rem;">
  <img src="images/7.jpg.jpeg"  class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kerala</h5>
    <p class="card-text">kerala tourism is famous for munnar,alappuzha,wayynand,cochin,kovalam,varkala,thekkady,kumarakom,idukki,bekal</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
<div class="COL-4 ml-4 mr-5">
			<div class="card" style="width: 18rem;">
  <img src="images/8.jpg.jpeg"  class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title pt-4">Mysore</h5>
    <p class="card-text">Mysore tourism is famous for the mysore palace,adjacent to the race course & foothillls of chamundi hills</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
<div class="COL-4 mr-4 ml-5">
			<div class="card" style="width: 18rem;">
  <img src="images/9.jpg" class="card-img-top mb-4" alt="...">
  <div class="card-body">
    <h5 class="card-title">kedarnath</h5>
    <p class="card-text">Kedarnath tourism is famous for gandhisarovar,phata,sonprayag,gaurikudtemple,vasukitallake,shankaracharyasamdhi</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
<div class="COL-4 ml-5">
			<div class="card" style="width: 18rem;">
  <img src="images/10.jpg.jpeg"  class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title pt-5 mt-2">ooty</h5>
    <p class="card-text">ooty tourism is famous for Avalanchelake,ootylake,emeraldlake,ootybotanicalgardens,deerpark</p>
    <a href="#" class="btn btn-warning">Book tickets</a>
  </div>
</div>
</div>
</div>
	<h2 class="pro  text-warning mt-4 mb-3 ">< /Places></h2>

</div>
<!---
<div id="social-media" class="container-fluid pt-5">
	<div class="container">
		<h4 class="text-warning mt-4 pt-3">Social Media</h4>
		<h2 class="text-white"> Catch me up over here</h2>
		<div class="row pt-4 pb-1">
			<div class="col-3 media_link btn" href="#">
				<div class="row">
				<div class="col-6 d-flex justify-content-start">
					<h3 class="pt-2 m-0 text-white">LinkedIn</h3>
				</div>
				<div class="col-6 d-flex justify-content-end align-items-center">
					<i class="fab fa-linkedin-in fa-2x text-secondary"></i>
				</div>
			</div>
		</div>
		<div class="col-3 media_link btn" href="#">
				<div class="row">
				<div class="col-6 d-flex justify-content-start">
					<h3 class="pt-2 m-0 text-white">GitHub</h3>
				</div>
				<div class="col-6 d-flex justify-content-end align-items-center">
					<i class="fab fa-github fa-2x text-secondary"></i>
				</div>
			</div>
		</div>
		<div class="col-3 media_link btn" href="#">
				<div class="row">
				<div class="col-6 d-flex justify-content-start">
					<h3 class="pt-2 m-0 text-white">Instagram</h3>
				</div>
				<div class="col-6 d-flex justify-content-end align-items-center">
					<i class="fab fa-instagram fa-2x text-secondary"></i>
				</div>
			</div>
		</div>
		<div class="col-3 media_link btn" href="#">
				<div class="row">
				<div class="col-6 d-flex justify-content-start">
					<h3 class="pt-2 m-0 text-white">Email</h3>
				</div>
				<div class="col-6 d-flex justify-content-end align-items-center">
					<i class="fas fa-envelope fa-2x text-secondary"></i>
				</div>
			</div>
		</div>
	</div>
	</div>
</div> 
<div class="container pt-4">
<div class="row">
	<div class="col-6">
<h3 class="text-warning">My Resume</h3>
<h4 class="text-white">U can better know my technical skills in my resume , I have done many projects according my skillset like Ive done a laptop repair billing section using C++ and done a project using Pyhton for generating captcha automatically after that  Ive done 2 more projects in web devolopment sector using HTML,CSS,JS even I've used React in a project.</h4>
		
	</div>
	<div class="col-6">
		<img class="res" src="images/res1.png" width="50%">
<a target="blank" id="resume" href="https://drive.google.com/file/d/1LmxHCZnCkSSajJAimTB8BiZq5P0g8cLS/view?usp=sharing"class="link btn btn-primary stretched-link ">resume</a>
		
	</div>
</div>
</div>
<br>------>

<div class="img-slider">
      <div class="slide active">
        <img src="images/9.jpg" width="50%" alt="">
        <div class="info">
          <h2>Slide 01</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
      <div class="slide">
        <img src="images/10.jpg.jpeg" width="20%" alt="">
        <div class="info">
          <h2>Slide 02</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
      <div class="slide">
        <img src="images/8.jpg.jpeg" alt="">
        <div class="info">
          <h2>Slide 03</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
      <div class="slide">
        <img src="images/7.jpg.jpeg" alt="">
        <div class="info">
          <h2>Slide 04</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
      <div class="slide">
        <img src="images/5.jpg.jpeg" width="50%" alt="">
        <div class="info">
          <h2>Slide 05</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
    </div>

    <script type="text/javascript">
    var slides = document.querySelectorAll('.slide');
    var btns = document.querySelectorAll('.btn');
    let currentSlide = 1;

    // Javascript for image slider manual navigation
    var manualNav = function(manual){
      slides.forEach((slide) => {
        slide.classList.remove('active');

        btns.forEach((btn) => {
          btn.classList.remove('active');
        });
      });

      slides[manual].classList.add('active');
      btns[manual].classList.add('active');
    }

    btns.forEach((btn, i) => {
      btn.addEventListener("click", () => {
        manualNav(i);
        currentSlide = i;
      });
    });

    // Javascript for image slider autoplay navigation
    var repeat = function(activeClass){
      let active = document.getElementsByClassName('active');
      let i = 1;

      var repeater = () => {
        setTimeout(function(){
          [...active].forEach((activeSlide) => {
            activeSlide.classList.remove('active');
          });

        slides[i].classList.add('active');
        btns[i].classList.add('active');
        i++;

        if(slides.length == i){
          i = 0;
        }
        if(i >= slides.length){
          return;
        }
        repeater();
      }, 10000);
      }
      repeater();
    }
    repeat();
    </script>

<br> 

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
